<?php
namespace App\Http\Controllers;


use App\Book;


class BooksController extends Controller {

    public function showIndex() {
// SELECT * FROM books
        $books = Book::all();
        return view('books', ['books' => $books]);
    }
  
  }
